  ___                _____ _  _   
 |_ _|___  __ ___  _|___  | || |  
  | |/ __|/ _` \ \/ /  / /| || |_ 
  | |\__ \ (_| |>  <  / / |__   _|
 |___|___/\__,_/_/\_\/_/     |_|
http://github.com/ph0neh1/github
Verson 1.0.7

Thank you for downloading GodMode7 source.
In the .rbxm file you can find all of the core scripts and the GUI itself.
This is a special fallout edition and heads up this is for only ServerSide aka can only be run on the server aka ROBLOX not on the applications like Synapse X, ScriptWare, KRNL, ECT.